//
//  AngleViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 01.11.2021.
//

import UIKit

class AngleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is TrigonometryViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
