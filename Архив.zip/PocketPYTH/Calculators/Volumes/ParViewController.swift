//
//  ParViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 05.12.2021.
//

import UIKit

class ParViewController: UIViewController {

    @IBOutlet weak var H: UITextField!
    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Result(_ sender: UIButton) {
        let h = Double(H.text!) ?? 0.0
        let a = Double(a.text!) ?? 0.0
        let b = Double(b.text!) ?? 0.0
        
        let V = a*b*h
        
        if (V - floor(V) == 0){
            result.text = String(Int(V))
        } else {
            result.text = String(V)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is VolumeViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
