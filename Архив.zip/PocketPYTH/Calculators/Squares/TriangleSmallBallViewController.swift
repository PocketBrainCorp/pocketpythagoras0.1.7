//
//  TriangleSmallBallViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 07.12.2021.
//

import UIKit

class TriangleSmallBallViewController: UIViewController {
    
    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var c: UITextField!
    @IBOutlet weak var result: UILabel!
    @IBOutlet weak var r: UITextField!
    
    @IBAction func Res(_ sender: UIButton) {
        let a = Double(a.text!) ?? 0.0
        let b = Double(b.text!) ?? 0.0
        let c = Double(c.text!) ?? 0.0
        let r = Double(r.text!) ?? 0.0
        
        let p = (a+b+c)/2
        let S = p*r
        
        if (S - floor(S) == 0) {
            result.text = String(Int(S))
        } else {
            result.text = String(S)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SquareViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
