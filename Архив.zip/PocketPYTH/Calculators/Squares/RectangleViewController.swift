//
//  RectangleViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 06.12.2021.
//

import UIKit

class RectangleViewController: UIViewController {

    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Res(_ sender: UIButton) {
        let a = Double(a.text!) ?? 0.0
        let b = Double(b.text!) ?? 0.0
        
        let S = a*b
        
        if (S - floor(S) == 0){
            result.text = String(Int(S))
        } else {
            result.text = String(S)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SquareViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
